<!DOCTYPE html>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reporte de venta</title>
    <!--
    <style>
        body {
            /*position: relative;*/
            /*width: 16cm;  */
            /*height: 29.7cm; */
            /*margin: 0 auto; */
            /*color: #555555;*/
            /*background: #FFFFFF; */
            font-family: Arial, sans-serif; 
            font-size: 11px;
            /*font-family: SourceSansPro;*/
        }

        #logo{
            float: left;
            margin-top: 0%;
            margin-left: -2%;
            margin-right: -4%;
        }
        #logo2{
            float: left;
            margin-top: 0%;
            margin-left: 0%;
            margin-right: 0%;
        }

        #imagen2{
            width: 200px;
        }
        #imagen{
            width: 60px;
            margin-left: -10px !important;
            margin-top: 13px;
        }

        #datos{
            float: left;
            margin-top: 0%;
            margin-left: 3%;
            margin-right: 2%;
            /*text-align: justify;*/
        }

        #encabezado{
            text-align: center;
            margin-left: 0%;
            margin-right: 3%;
            
        }

        #fact{
            /*position: relative;*/
            float: right;
            margin-top: 13px;
            margin-left: 15px;
            margin-right: 30px;
            font-size: 14px;
        }

        section{
            clear: left;
        }
        #cliente{
            text-align: left;
        }
        #facliente{
            width: 90%;
            border-collapse: collapse;
            border-spacing: 0;
            margin-bottom: 15px;
        }
        #fac, #fv, #fa{
            color: #FFFFFF;
            font-size: 15px;
        }
        #facliente thead{
            padding: 20px;
           
            text-align: left;
            border-bottom: 1px solid #FFFFFF;  
        }
        #facvendedor{
            width: 100%;
            border-collapse: collapse;
            border-spacing: 0;
            margin-bottom: 15px;
        }

        #facvendedor thead{
            padding: 20px;
            /*background: #2183E3;*/
            text-align: center;
            border-bottom: 1px solid #FFFFFF;  
        }
        #facarticulo{
            width: 100%;
            border-collapse: collapse;
            border-spacing: 0;
            margin-bottom: 15px;
        }
        #facarticulo thead{
            padding: 20px;
            background: #2183E3;
            text-align: center;
            border-bottom: 1px solid #FFFFFF;  
        }
        #gracias{
            text-align: center; 
        }
    </style>
    -->
    <body>
        <table>
            <thead>
                <tr>
                    <?php if($facturacion->num_factura): ?>
                        <th colspan="8">INFORME DE FACTURA N° <?php echo e($facturacion->num_factura); ?></th>
                    <?php else: ?>
                        <th colspan="8">INFORME DE FACTURA</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>N° Factura:</td>
                    <?php if($facturacion->num_factura && $facturacion->num_factura!=0 && $facturacion->num_factura!=''): ?>
                    <td><?php echo e($facturacion->num_factura); ?></td>
                    <?php else: ?>
                    <td>N/A</td>
                    <?php endif; ?>

                    <td>Caja:</td>
                    <td><?php echo e($caja->nombre); ?></td>

                    <td>Cajero:</td>
                    <td><?php echo e($user->usuario); ?></td>

                    <td>Cliente:</td>
                    <td><?php echo e($tercero->nombre1); ?> <?php echo e($tercero->nombre2); ?> <?php echo e($tercero->apellido1); ?> <?php echo e($tercero->apellido2); ?></td>
                </tr>
                <tr>
                    <td>Fecha:</td>
                    <td><?php echo e($facturacion->fecha); ?></td>

                    <td>Lugar:</td>
                    <td><?php echo e($lugar->zona); ?></td>

                    <td>Detalle:</td>
                    <td><?php echo e($facturacion->detalle); ?></td>

                    <td>Estado:</td>
                    <?php if($facturacion->estado==1): ?>
                    <td>Activa</td>
                    <?php elseif($facturacion->estado==2): ?>
                    <td>Registrada</td>
                    <?php elseif($facturacion->estado==3): ?>
                    <td>Enviada</td>
                    <?php elseif($facturacion->estado==4): ?>
                    <td>Anulada</td>
                    <?php endif; ?>
                </tr>
            </tbody>
        </table>
        <br>
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th>Presentacion</th>
                    <th>Talla</th>
                    <th>Precio</th>
                    <th>Cantidad</th>
                    <th>Descuento</th>
                    <th>Iva</th>
                    <th>Vr sin iva</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($det->id); ?></td>
                        <td><?php echo e($det->nombre); ?></td>
                        <td><?php echo e($det->nom_presentacion); ?></td>
                        <td><?php echo e($det->talla); ?></td>
                        <td><?php echo e($det->valor_final); ?></td>
                        <td><?php echo e($det->cantidad); ?></td>
                        <td><?php echo e($det->valor_descuento); ?></td>
                        <td><?php echo e($det->valor_iva); ?></td>
                        <td><?php echo e($det->valor_subtotal); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="8">Valor total iva</td>
                    <td><?php echo e($facturacion->valor_iva); ?></td>
                </tr>
                <tr>
                    <td colspan="8">Valor total sin iva</td>
                    <td><?php echo e($facturacion->subtotal); ?></td>
                </tr>
                <tr>
                    <td colspan="8">Valor total neto</td>
                    <td><?php echo e($facturacion->total); ?></td>
                </tr>
                <tr>
                    <td colspan="8">Valor abono</td>
                    <td><?php echo e($facturacion->abono); ?></td>
                </tr>
                <tr>
                    <td colspan="8">Valor saldo</td>
                    <td><?php echo e($facturacion->saldo); ?></td>
                </tr>
            </tbody>
            <?php
            // echo '<pre>';
            // print_r($detalles);
            // echo '</pre>';
            ?>
        </table>
    </body>
</html>