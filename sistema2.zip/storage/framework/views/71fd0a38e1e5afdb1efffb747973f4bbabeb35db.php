    <?php $__env->startSection('contenido'); ?>
<?php
    $menu_usuario2 = Session::get('menu_usu');
?>
    <?php if(Auth::check()): ?>
            <template v-if="menu==0">
                <h1>Escritorio</h1>
            </template>
            
			<?php $__currentLoopData = $menu_usuario2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_usu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if(count($menu_usu['hijos'])>0): ?>
					<?php $__currentLoopData = $menu_usu['hijos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_hijo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<template v-if="menu==<?php echo e($menu_hijo['menu']); ?>">
							<<?php echo e($menu_hijo['template_menu']); ?> :ruta="ruta" :permisos-user="permisosUser['<?php echo e($menu_hijo['template_menu']); ?>']"></<?php echo e($menu_hijo['template_menu']); ?>>
						</template>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
            <template v-if="menu==999991">
                <user :ruta="ruta"></user>
            </template>

            <template v-if="menu==999992">
                <rol :ruta="ruta"></rol>
            </template>

            <template v-if="menu==999993">
                <modulo :ruta="ruta"></modulo>
            </template>
            
            <!-- <template v-if="menu==11">
                <h1>Ayuda</h1>
            </template> -->

            <template v-if="menu==999994">
                <h1>Acerca de</h1>
            </template>   


    <?php endif; ?>
       
        
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>