<?php
header("Location: public");
?>
